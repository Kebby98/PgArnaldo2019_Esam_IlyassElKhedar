package it.unibs.arnaldo.ilyass;

import java.io.FileInputStream;
import java.util.*;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

public class Mappa {
	
	private TreeMap<Integer, ArrayList<String>> mappa_gioco = new TreeMap<Integer, ArrayList<String>>();
	ArrayList<String> passi = new ArrayList<String>();
	private XMLInputFactory xmlif = null;
	private XMLStreamReader xmlr = null;
	
	public Mappa ( TreeMap<Integer, ArrayList<String>> mappa ) {
		this.mappa_gioco = mappa;
	}
	
	public void letturaXML() {
		try {
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader( "1) base.xml", new FileInputStream("1) base.xml") );
			while( xmlr.hasNext() ) {
				switch( xmlr.getEventType() ) {
				case XMLStreamConstants.START_DOCUMENT:
					continue;
				case XMLStreamConstants.START_ELEMENT:
					for ( int i = 0; i < xmlr.getAttributeCount(); i++ ) {
						if ( xmlr.getAttributeLocalName(i).equals("cell") ) {
							for ( int j = 0; j < xmlr.getAttributeCount(); j++ )
								passi.add(xmlr.getAttributeLocalName(j));
							mappa_gioco.put(i, passi);
						}
					} 
				}
			}
		}
		catch( Exception err ) {
			System.out.println("errore nella ricezizone del file");
		}
	}
	
	public TreeMap<Integer, ArrayList<String>> getMappa() {
		return mappa_gioco;
	}
}
