package it.unibs.arnaldo.ilyass;

public class Giocatore {
	
	private String nome;
	private int vita;
	private int felicita;

	public Giocatore( String _nome, int _vita, int _felicita ) {
		this.nome = _nome;
		this.vita = _vita;
		this.felicita = _felicita;
	}
	
	public String getNome() {
		return nome;
	}
	
	public int getVita() {
		return vita;
	}
	
	public int getFelicita() {
		return felicita;
	}
	
	public int setVita( int nuova_vita ) {
		return vita = nuova_vita;
	}
	
	public int setFelicita( int nuova_felicita ) {
		return felicita = nuova_felicita;
	}
	
}
