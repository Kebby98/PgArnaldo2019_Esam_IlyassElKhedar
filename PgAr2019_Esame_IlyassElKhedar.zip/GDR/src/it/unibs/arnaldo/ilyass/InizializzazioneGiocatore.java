package it.unibs.arnaldo.ilyass;

import it.unibs.libr.ilyass.DatiInput;
import it.unibs.libr.ilyass.Menu;
import it.unibs.libr.ilyass.Operazioni;

public class InizializzazioneGiocatore {
	
	private static String messaggio1 = "Inserisci il tuo nome";
	private static String messaggio2 = "Che arma vuoi:";
	
	public static Giocatore nuovoGiocatore() {
		String nome = DatiInput.leggiStringa(messaggio1);
		return new Giocatore(nome, Operazioni.estrazioniInteri(20, 80), Operazioni.estrazioniInteri(20, 80));
	}
}
