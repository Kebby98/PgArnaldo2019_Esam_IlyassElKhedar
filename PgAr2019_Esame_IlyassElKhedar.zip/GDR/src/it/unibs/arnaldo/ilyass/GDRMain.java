package it.unibs.arnaldo.ilyass;

import java.util.ArrayList;
import java.util.TreeMap;

import it.unibs.libr.ilyass.Menu;

//nel seguente codice c'� solo l'implementazione del nucleo

public class GDRMain {
	
	private static String messaggio_benvenuto = "Benvenuto in questo audace GDR";
	private static String messaggio_addio1 = "Complimenti per aver finito il gioco";
	private static String messaggio_addio2 = "Mi spiace ma sei morto";
	public static Giocatore player;
	static TreeMap<Integer, ArrayList<String>> mappa = new TreeMap<Integer, ArrayList<String>>();
	static Mappa mappa_gioco = new Mappa(mappa);
	private static boolean morte = true;
	
	public static void main(String[] args) {
		Giocatore player = InizializzazioneGiocatore.nuovoGiocatore();
		System.out.println(messaggio_benvenuto);
		mappa_gioco.letturaXML();
		if ( messaggioZero() == true )
			System.out.println(messaggio_addio2);
		else
			System.out.println(messaggio_addio1);
	}
	
	/*
	 * attraverso una serie di metodi annidati si riesce a switchare fra le varie opzioni del gdr,
	 * si implementa un oggetto Mappa, e u giocatore protagonista della storia
	 * nel caso il protagonista morisse, attraverso i metodi annidati riesco a capire se � morto anche se arriva all'ultima tappa
	 */
	
	public static boolean messaggioZero() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(0);
		System.out.println( messaggi.get(0) + "\n" + messaggi.get(0) );
		if ( primoMessaggio() == true )
			morte = true;
		else
			morte = false;
		return morte;
	}//attraverso la mappa viene preso il primo nodo che stama il messaggio contenuto
	
	public static boolean primoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(1);
		int scelta = Menu.menuTreVociContIntero(messaggi.get(0), messaggi.get(1), messaggi.get(2), messaggi.get(3));
		switch(scelta) {
		case 1:
			if ( secondoMessaggio() == true )
				morte = true;
			else
				morte = false;
			break;
		case 2:
			if ( terzoMessaggio() == true )
				morte = true;
			else
				morte = false;
			break;
		case 3:
			primoMessaggio();
			morte = false;
			break;
		}	
		return morte;
	}//viene presa la seconda opzione con dei switch che richiamano metodi a loro volta
	
	public static boolean secondoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(2);
		int scelta = Menu.menuTreVociContIntero(messaggi.get(0), messaggi.get(1), messaggi.get(2), messaggi.get(3));
		switch(scelta) {
		case 1:
			player.setFelicita( player.getFelicita() + 5 );
			messaggioZero();
			morte = false;
			break;
		case 2:
			player.setFelicita( player.getFelicita() - 5 );
			if ( terzoMessaggio() == true )
				morte = true;
			else
				morte = false;
			morte = false;
			break;
		case 3:
			if ( quartoMessaggio() == true )
				morte = true;
			else
				morte = false;
			break;
		}
		return morte;
	}
	
	public static boolean terzoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(3);
		System.out.println(messaggi.get(0) + "\n" + messaggi.get(1));
		if ( quartoMessaggio() == true )
			morte = true;
		else
			morte = false;
		return morte;
	}
	
	public static boolean quartoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(4);
		int scelta = Menu.menuDueVociConIntero(messaggi.get(0), messaggi.get(1), messaggi.get(2));
		switch(scelta) {
		case 1:
			player.setFelicita( player.getFelicita() - 8 );
			player.setVita( player.getVita() - 5 );
			if ( quintoMessaggio() == true )
				morte = true;
			else
				morte = false;
			break;
		case 2:
			player.setVita( player.getVita() - 10 );
			if ( sestoMessaggio() == true )
				morte = true;
			else
				morte = false;
			break;
		}
		return morte;
	}
	
	public static boolean quintoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(5);
		System.out.println(messaggi.get(0));
		player.setVita(0);
		return morte = true;
	}
	
	public static boolean sestoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(6);
		int scelta = Menu.menuDueVociConIntero(messaggi.get(0), messaggi.get(1), messaggi.get(2));
		switch(scelta) {
		case 1:
			player.setFelicita( player.getFelicita() + 8 );
			player.setVita( player.getVita() + 1 );
			settimoMessaggio();
			morte = false;
			break;
		case 2:
			player.setVita(0);
			morte = true;
			settimoMessaggio();
			break;
		}
		return morte;
	}
	
	public static boolean settimoMessaggio() {
		ArrayList<String> messaggi = mappa_gioco.getMappa().get(7);
		if ( morte == true )
			return true;
		else
			return false;
	}

}
